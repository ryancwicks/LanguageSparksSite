document.write ( '\
<p>Copyright &copy; Language Sparks Speech Services 2014 | Designed by <a href="http://www.edg3.co.uk/">edg3.co.uk</a> |  Valid <a href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; <a href="http://validator.w3.org/">XHTML</a></p> \
')
