document.write ( '\
<h1>Language Sparks Speech Services</h1> \
<p>Marja Wicks BA., MSc., SLP(C), Reg. CASLPO</p> \
<ul> \
    <li><a href="./index.html">Home</a></li> \
    <li><a href="./Services.html">Services</a></li> \
    <li><a href="./about.html">About Me</a></li> \
    <li><a href="./links.html">Links & Resources</a></li> \
    <li><a href="./contact.html">Contact</a></li> \
</ul>\
')
