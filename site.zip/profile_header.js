document.write ('\
                <head profile="http://gmpg.org/xfn/11">\
    <title>Language Sparks Speech Services</title>	\
    <link rel="shortcut icon" href="image/favicon.ico" />\
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />\
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />\
    <meta http-equiv="content-language" content="en-us" />\
    <meta http-equiv="imagetoolbar" content="false" />\
    <meta name="author" content="Ryan Wicks" />\
    <meta name="copyright" content="Copyright (c) Language Sparks Speech Services 2014" />\
    <meta name="description" content="" />\
    <meta name="keywords" content="Speech Language Pathology, Speech Therapy, Speech Services, Articulation, Stuttering, Dysphagia, Apraxia, Voice, Social Language, Communication, Autism, CASLPA, CASLPO, OSLA, Lidcombe" /> \
    <meta name="last-modified" content="" />\
    <meta name="mssmarttagspreventparsing" content="true" />\
    <meta name="robots" content="index, follow, noarchive" />\
    <meta name="revisit-after" content="7 days" />\
</head>\
                \
 ')
