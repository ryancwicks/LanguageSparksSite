document.write ( '\
<h1>Latest News</h1> \
<p>22 August 2014 - I am now trained in the Lidcombe program for pre-schoolers who stutter.</p> \
<p>1 May 2014 - May is speech and hearing month. Check out <a href="http://www.maymonth.ca">maymonth.ca</a> for information, events, children\'s contests, and more...</p> \
<p>1 February 2014 - Welcome to our new site.</p> \
\
')
